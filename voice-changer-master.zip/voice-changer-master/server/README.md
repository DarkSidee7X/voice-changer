MMVC Server

See this document. 
[Japanese](/README_dev_ja.md) / [English](/README_dev_en.md)

