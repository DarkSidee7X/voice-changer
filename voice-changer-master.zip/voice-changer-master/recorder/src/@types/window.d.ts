
interface Window {
}
