#!/bin/bash

cd demo && ncu -u && npm install && npm run build:prod && cd -
